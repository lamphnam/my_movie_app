export const DOMAIN_URL = "https://hnamphim.dpdns.org";
