// FILE: src/components/Header.tsx
import SearchForm from '@/components/SearchForm'
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from '@/components/ui/navigation-menu'
import { filterData } from '@/data/filters'
import { cn } from '@/lib/utils'
import { Film, Clock, Bookmark, Search } from 'lucide-react'
import { Link } from 'react-router-dom'
import { Button } from './ui/button'
import { useState } from 'react'

const Header = () => {
  const [showSearch, setShowSearch] = useState(false)

  return (
    <header className="fixed top-0 left-0 right-0 z-50 border-b border-border/50 bg-background/95 backdrop-blur-sm">
      <div className="container-desktop flex h-16 items-center justify-between gap-4">

        {/* === Logo === */}
        <Link to="/" className="flex items-center gap-2.5 font-bold shrink-0">
          <div className="w-9 h-9 rounded-lg bg-primary flex items-center justify-center">
            <Film className="text-primary-foreground w-5 h-5" />
          </div>
          <span className="text-lg font-extrabold tracking-tight hidden sm:inline">
            <span className="text-primary">HNAM</span>
            <span className="text-foreground">Phim</span>
          </span>
        </Link>

        {/* === Desktop Navigation === */}
        <nav className="hidden lg:flex items-center gap-1">
          <Link to="/" className="px-3 py-2 text-sm font-medium text-foreground/80 hover:text-foreground transition-colors rounded-md hover:bg-secondary">
            Trang chủ
          </Link>
          <NavigationMenu>
            <NavigationMenuList className="gap-0">
              <NavigationMenuItem>
                <NavigationMenuTrigger className="h-9 px-3 text-sm font-medium bg-transparent hover:bg-secondary data-[state=open]:bg-secondary">
                  Thể loại
                </NavigationMenuTrigger>
                <NavigationMenuContent>
                  <ul className="grid w-[480px] gap-1 p-3 grid-cols-3 surface-card">
                    {filterData.genres.slice(0, 12).map((genre) => (
                      <ListItem key={genre.id} to={`/genre/${genre.slug}`} title={genre.name} />
                    ))}
                  </ul>
                </NavigationMenuContent>
              </NavigationMenuItem>
              <NavigationMenuItem>
                <NavigationMenuTrigger className="h-9 px-3 text-sm font-medium bg-transparent hover:bg-secondary data-[state=open]:bg-secondary">
                  Quốc gia
                </NavigationMenuTrigger>
                <NavigationMenuContent>
                  <ul className="grid w-[400px] gap-1 p-3 grid-cols-2 surface-card">
                    {filterData.countries.slice(0, 10).map((country) => (
                      <ListItem key={country.id} to={`/country/${country.slug}`} title={country.name} />
                    ))}
                  </ul>
                </NavigationMenuContent>
              </NavigationMenuItem>
              <NavigationMenuItem>
                <NavigationMenuTrigger className="h-9 px-3 text-sm font-medium bg-transparent hover:bg-secondary data-[state=open]:bg-secondary">
                  Năm
                </NavigationMenuTrigger>
                <NavigationMenuContent>
                  <ul className="grid w-[320px] gap-1 p-3 grid-cols-3 surface-card">
                    {filterData.years.slice(0, 9).map((year) => (
                      <ListItem key={year.id} to={`/year/${year.slug}`} title={year.name} />
                    ))}
                  </ul>
                </NavigationMenuContent>
              </NavigationMenuItem>
            </NavigationMenuList>
          </NavigationMenu>
          <Link to="/filter" className="px-3 py-2 text-sm font-medium text-foreground/80 hover:text-foreground transition-colors rounded-md hover:bg-secondary">
            Lọc phim
          </Link>
        </nav>

        {/* === Center Search (Desktop) === */}
        <div className="hidden lg:block flex-1 max-w-md mx-4">
          <SearchForm />
        </div>

        {/* === Right Actions === */}
        <div className="flex items-center gap-2">
          {/* Mobile Search Toggle */}
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden h-9 w-9"
            onClick={() => setShowSearch(!showSearch)}
          >
            <Search className="h-5 w-5" />
          </Button>

          {/* Desktop Quick Actions */}
          <div className="hidden md:flex items-center gap-1">
            <Button variant="ghost" size="sm" className="h-9 px-3 gap-2 text-muted-foreground hover:text-foreground">
              <Clock className="h-4 w-4" />
              <span className="hidden xl:inline text-sm">Lịch sử</span>
            </Button>
            <Button variant="ghost" size="sm" className="h-9 px-3 gap-2 text-muted-foreground hover:text-foreground">
              <Bookmark className="h-4 w-4" />
              <span className="hidden xl:inline text-sm">Bộ sưu tập</span>
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Search Dropdown */}
      {showSearch && (
        <div className="lg:hidden border-t border-border bg-background p-4">
          <SearchForm />
        </div>
      )}
    </header>
  )
}

const ListItem = ({ className, title, to }: { title: string; to: string; className?: string }) => {
  return (
    <li>
      <NavigationMenuLink asChild>
        <Link
          to={to}
          className={cn(
            'block select-none rounded-md px-3 py-2 text-sm leading-none no-underline outline-none transition-colors hover:bg-secondary hover:text-foreground focus:bg-secondary',
            'text-foreground/80',
            className,
          )}
        >
          {title}
        </Link>
      </NavigationMenuLink>
    </li>
  )
}

export default Header